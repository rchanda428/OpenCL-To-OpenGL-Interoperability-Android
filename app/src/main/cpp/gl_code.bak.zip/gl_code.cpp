/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// OpenGL ES 2.0 code

#include <jni.h>
#include <android/log.h>
#include <android/bitmap.h>

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "cl_code.h"

#define  LOG_TAG    "libgl2jni"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

namespace abc {}

static void printGLString(const char *name, GLenum s) {
    const char *v = (const char *) glGetString(s);
    LOGI("GL %s = %s\n", name, v);
}

static void checkGlError(const char *op) {
    for (GLint error = glGetError(); error; error = glGetError()) {
        LOGI("after %s() glError (0x%x)\n", op, error);
    }
}

static const char* PROGRAM_IMAGE_2D_COPY_SOURCE[] = {
        "__constant sampler_t imageSampler = CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE   | CLK_FILTER_NEAREST;\n",
        "__kernel void image2dCopy(__read_only image2d_t input, __write_only image2d_t output )\n",
        "{\n",
        "    int2 coord = (int2)(get_global_id(0), get_global_id(1));\n",
        "    uint4 temp = read_imageui(input, imageSampler, coord);\n",
        "    write_imageui(output, coord, temp);\n",
        "}"
};

cl_wrapper       wrapper;
static cl_uint PROGRAM_IMAGE_2D_COPY_SOURCE_LEN;
cl_context       context;
cl_command_queue command_queue;
cl_program       program_image_2d_program;
cl_kernel        program_image_2d_kernel;

cl_int status = CL_SUCCESS;
// Create and initialize image objects
cl_image_desc imageDesc;
cl_image_format imageFormat;
cl_mem inputImage2D;
cl_mem outputImage2D;

void init_cl()
{
    PROGRAM_IMAGE_2D_COPY_SOURCE_LEN = sizeof(PROGRAM_IMAGE_2D_COPY_SOURCE) / sizeof(const char*);
    context = wrapper.get_context();
    command_queue = wrapper.get_command_queue();
    program_image_2d_program = wrapper.make_program(PROGRAM_IMAGE_2D_COPY_SOURCE, PROGRAM_IMAGE_2D_COPY_SOURCE_LEN);
    program_image_2d_kernel = wrapper.make_kernel("image2dCopy", program_image_2d_program);

    memset(&imageDesc, '\0', sizeof(cl_image_desc));
    imageDesc.image_type = CL_MEM_OBJECT_IMAGE2D;
    imageDesc.image_width = 1440;
    imageDesc.image_height = 1080;

    imageFormat.image_channel_data_type = CL_UNSIGNED_INT8;
    imageFormat.image_channel_order = CL_R;

    std::string src_filename = std::string("/storage/emulated/0/opencvTesting/out148Yonly.yuv");
    std::ifstream fin(src_filename, std::ios::binary);
    if (!fin) {
        DPRINTF("Couldn't open file %s", src_filename.c_str());
        std::exit(EXIT_FAILURE);
    }
    const auto        fin_begin = fin.tellg();
    fin.seekg(0, std::ios::end);
    const auto        fin_end = fin.tellg();
    const size_t      buf_size = static_cast<size_t>(fin_end - fin_begin);
    std::vector<char> buf(buf_size);
    fin.seekg(0, std::ios::beg);
    fin.read(buf.data(), buf_size);

    inputImage2D = clCreateImage(context,
                                 CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR,
                                 &imageFormat,
                                 &imageDesc,
                                 buf.data(),
                                 &status);

    // Create 2D output image
    /*outputImage2D = clCreateImage(context,
                                  CL_MEM_WRITE_ONLY,
                                  &imageFormat,
                                  &imageDesc,
                                  0,
                                  &status);*/
}

void execute_cl()
{
    //glFinish();
    cl_mem objs[] = { outputImage2D };
    //clEnqueueAcquireGLObjects(command_queue, 1, objs, 0, NULL, NULL);
    status = clSetKernelArg(program_image_2d_kernel,0,sizeof(cl_mem),&inputImage2D);
    status = clSetKernelArg(program_image_2d_kernel,1,sizeof(cl_mem),&outputImage2D);
    size_t globalThreads[] = { 1440, 1080 };

    struct timeval startNDKKernel, endNDKKernel;
    gettimeofday(&startNDKKernel, NULL);
    status = clEnqueueNDRangeKernel( command_queue, program_image_2d_kernel, 2, NULL, globalThreads, 0, 0, NULL,0);
    clFinish(command_queue);
    //clEnqueueReleaseGLObjects(command_queue, 1, objs, 0, NULL, NULL);
    clFinish(command_queue);
    gettimeofday(&endNDKKernel, NULL);
    DPRINTF("time taken :%ld",((endNDKKernel.tv_sec * 1000000 + endNDKKernel.tv_usec)- (startNDKKernel.tv_sec * 1000000 + startNDKKernel.tv_usec)));
#if OPENGL
    // Enqueue Read Image
    static int count = 0;
    if( count > 50 && count < 70 ) {
        size_t origin[] = { 0, 0, 0 };
        size_t region[] = { 1440, 1080, 1 };

        unsigned char *outputImageData2D = (unsigned char*)malloc(1440* 1080);
        // Read output of 2D copy
        clEnqueueAcquireGLObjects(command_queue, 1, objs, 0, NULL, NULL);
        status = clEnqueueReadImage(command_queue, outputImage2D, 1,
                                origin, region, 0, 0, outputImageData2D, 0, 0, 0);
        clEnqueueReleaseGLObjects(command_queue, 1, objs, 0, NULL, NULL);

        std::string filename("/storage/emulated/0/opencvTesting/output_copy" + std::to_string(count)+".yuv");
        std::ofstream fout(filename, std::ios::binary);
        if (!fout) {
            std::cerr << "Couldn't open file " << filename << "\n";
            std::exit(EXIT_FAILURE);
        }

        const size_t buf_size = imageDesc.image_height * imageDesc.image_width;
        char *output_image_U8 = new char[buf_size];

        for (int pix_i = 0; pix_i < buf_size; pix_i++)
            output_image_U8[pix_i] = (unsigned char) outputImageData2D[pix_i];
        fout.write(output_image_U8, buf_size);
        fout.close();
        delete[] output_image_U8;
        free(outputImageData2D);

    }
    count++;
#endif
#if OPENCL_LUT
#endif
}

auto gVertexShader =
        "attribute vec4 aPosition;\n"
            "attribute vec2 aTexCoord;\n"
            "varying vec2 vTexCoord;\n"
            "void main() {\n"
            "   gl_Position = vec4(aPosition, 0.0, 1.0);\n"
            "   vTexCoord = aTexCoord;\n"
            "}";

auto gFragmentShader =
        "precision mediump float;\n"
            "uniform sampler2D rubyTexture;\n"
            "varying vec2 vTexCoord;\n"
            "void main() {\n"
            "   vec4 color = texture2D(rubyTexture, vTexCoord);\n"
            "   gl_FragColor = color;\n"
            "}";

GLuint loadShader(GLenum shaderType, const char *pSource) {
    GLuint shader = glCreateShader(shaderType);
    if (shader) {
        glShaderSource(shader, 1, &pSource, NULL);
        glCompileShader(shader);
        GLint compiled = 0;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
        if (!compiled) {
            GLint infoLen = 0;
            glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
            if (infoLen) {
                char *buf = (char *) malloc(infoLen);
                if (buf) {
                    glGetShaderInfoLog(shader, infoLen, NULL, buf);
                    LOGE("Could not compile shader %d:\n%s\n",
                         shaderType, buf);
                    free(buf);
                }
                glDeleteShader(shader);
                shader = 0;
            }
        }
    }

    return shader;
}

GLuint createProgram(const char *pVertexSource, const char *pFragmentSource) {
    GLuint vertexShader = loadShader(GL_VERTEX_SHADER, pVertexSource);
    if (!vertexShader) {
        return 0;
    }

    GLuint pixelShader = loadShader(GL_FRAGMENT_SHADER, pFragmentSource);
    if (!pixelShader) {
        return 0;
    }

    GLuint program = glCreateProgram();
    if (program) {
        glAttachShader(program, vertexShader);
        checkGlError("glAttachShader");
        glAttachShader(program, pixelShader);
        checkGlError("glAttachShader");
        glLinkProgram(program);
        GLint linkStatus = GL_FALSE;
        glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);
        if (linkStatus != GL_TRUE) {
            GLint bufLength = 0;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &bufLength);
            if (bufLength) {
                char *buf = (char *) malloc(bufLength);
                if (buf) {
                    glGetProgramInfoLog(program, bufLength, NULL, buf);
                    LOGE("Could not link program:\n%s\n", buf);
                    free(buf);
                }
            }
            glDeleteProgram(program);
            program = 0;
        }
    }
    return program;
}

GLuint programId;
GLuint aPosition;
GLuint aTexCoord;
GLuint rubyTexture;
GLuint rubyTextureSize;
GLuint rubyInputSize;
GLuint rubyOutputSize;

GLuint texture_map;

int scnw, scnh, vw, vh;
float bw, bh;
void *img;
std::vector<char> buf(1555200);
char *gVs, *gFs;

bool initProgram() {
//    LOGI("initProgram vs=%s fs=%s", gVs, gFs);
    if(!gVs)
        gVs = (char *)gVertexShader;
    if(!gFs)
        gFs = (char *)gFragmentShader;
    programId = createProgram(gVs, gFs);
    if (!programId) {
        LOGE("Could not create program.");
        return false;
    }

    aPosition = glGetAttribLocation(programId, "aPosition");
    aTexCoord = glGetAttribLocation(programId, "aTexCoord");
    rubyTexture = glGetUniformLocation(programId, "rubyTexture");
    rubyTextureSize = glGetUniformLocation(programId, "rubyTextureSize");
    rubyInputSize = glGetUniformLocation(programId, "rubyInputSize");
    rubyOutputSize = glGetUniformLocation(programId, "rubyOutputSize");

    return true;
}

bool setupGraphics(int w, int h) {
    scnw = w;
    scnh = h;
    LOGI("setupGraphics(%d, %d)", w, h);
    glViewport(0, 0, scnw, scnh);
    return true;
}

const GLfloat gTriangleVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,

        -1.0f, 1.0f,
        1.0f,-1.0f,
        1.0f,1.0f
};

const GLfloat gTexVertices[] = {
        0.0f, 1.0f,
        1.0f, 1.0f,
        0.0f, 0.0f,

        0.0f, 0.0f,
        1.0f,1.0f,
        1.0f,0.0f
};

void renderFrame() // 16.6ms
{
    float grey;
    grey = 0.00f;

    glClearColor(grey, grey, 0.5f, 1.0f);
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    glEnable( GL_TEXTURE_2D );

    glBindTexture( GL_TEXTURE_2D, texture_map);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    outputImage2D = clCreateFromGLTexture(context, CL_MEM_WRITE_ONLY, GL_TEXTURE_2D, 0, texture_map, NULL);
    execute_cl();
    glTexImage2D(GL_TEXTURE_2D, 0, GL_BYTE, bw, bh, 0, GL_BYTE, GL_UNSIGNED_BYTE, 0);
    glUseProgram(programId);

    glVertexAttribPointer(aPosition, 2, GL_FLOAT, GL_FALSE, 0, gTriangleVertices);
    glEnableVertexAttribArray(aPosition);

    glVertexAttribPointer(aTexCoord, 2, GL_FLOAT, GL_FALSE, 0, gTexVertices);
    glEnableVertexAttribArray(aTexCoord);

    glUniform2f(rubyTextureSize, bw, bh);
    glUniform1i(rubyTexture, 0);

    glDrawArrays(GL_TRIANGLES, 0, 6);
    glFinish();
    clReleaseMemObject(outputImage2D);
}

void _init(JNIEnv *env, jobject bmp) {
    printGLString("Version", GL_VERSION);
    printGLString("Vendor", GL_VENDOR);
    printGLString("Renderer", GL_RENDERER);
    printGLString("Extensions", GL_EXTENSIONS);

    bw = 1440;
    bh = 1080;

    glGenTextures(1, &texture_map);
    glBindTexture(GL_TEXTURE_2D, texture_map);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_BYTE, bw, bh, 0, GL_BYTE, GL_UNSIGNED_BYTE, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void _loadShader(JNIEnv *env, jstring jvs, jstring jfs) {
    jboolean b;
    if(jvs) {
        const char *vs = env->GetStringUTFChars(jvs, &b);
        gVs = vs? strdup(vs) : NULL;
        env->ReleaseStringUTFChars(jvs, vs);
    } else
        gVs = (char *)gVertexShader;

    if(jfs) {
        const char *fs = env->GetStringUTFChars(jfs, &b);
        gFs = fs? strdup(fs) : NULL;
        env->ReleaseStringUTFChars(jfs, fs);
    } else
        gFs = (char *)gFragmentShader;

    initProgram();
}

extern "C" {
JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_init(JNIEnv *env, jobject obj, jobject bmp)
{
    //testOpencl();
    test_cl_image();
    init_cl();
    _init(env, bmp);
}

JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_resize(JNIEnv *env, jobject obj, jint width, jint height)
{
    setupGraphics(width, height);
}

JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_step(JNIEnv *env, jobject obj)
{
    renderFrame();
}

JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_loadShader(JNIEnv *env, jobject obj, jstring vs, jstring fs)
{
    _loadShader(env, vs, fs);
}
};